<html>
<head>
<meta http-equiv="REFRESH"content="0.00001;url=https://www.apple.com/?id=nav">
</head>
<body>